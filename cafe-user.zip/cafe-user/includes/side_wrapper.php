<?php
// session_start();
?>

<div class="sidebar-wrapper" >
    		<div class="logo text-center" >
	             <a href="../index.php" style="font-size: 28px;">
	             	<span style="color: #000 !important; font-family: 'satisfy';">Cafe </span> 
	             	<span style="color: #be9c79 !important;font-family: 'satisfy';">House </span>
	             </a>
         	</div> 
            <ul class="nav">
                <li>
                    <a href="profile.php">
                        <i class="pe-7s-user"></i>
                        <p>Profile</p>
                    </a>
                </li>
                <li>
                    <a href="sub_detail.php">
                        <i class="pe-7s-ribbon"></i>
                        <p>Subscription</p>
                    </a>
                </li>
				<li>
                    <a href="reservations.php">
                        <i class="pe-7s-note2"></i>
                        <p>Table reservations</p>
                    </a>
                </li>
			
                
            </ul>
    	</div>